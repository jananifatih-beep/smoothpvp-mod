package com.smoothpvp.features;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.ParticlesMode;

/**
 * No Particles - matikan semua partikel untuk FPS boost
 * Toggle ON = minimal partikel, OFF = semua partikel normal
 */
public class NoParticle {

    private boolean enabled = false;

    public void onTick(MinecraftClient client) {
        if (client.options == null) return;

        if (enabled) {
            // Set partikel ke MINIMAL
            client.options.getParticles().setValue(ParticlesMode.MINIMAL);
        } else {
            // Kembalikan ke ALL
            client.options.getParticles().setValue(ParticlesMode.ALL);
        }
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options != null) {
            client.options.getParticles().setValue(
                enabled ? ParticlesMode.MINIMAL : ParticlesMode.ALL
            );
            client.options.write();
        }
    }

    public void setEnabled(boolean v) {
        enabled = v;
    }
}
