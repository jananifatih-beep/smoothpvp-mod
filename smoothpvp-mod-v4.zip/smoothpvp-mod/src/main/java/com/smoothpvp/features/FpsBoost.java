package com.smoothpvp.features;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GraphicsMode;

/**
 * FPS Boost - otomatis turunkan setting saat FPS drop
 * dan kembalikan saat FPS stabil
 */
public class FpsBoost {

    private boolean enabled      = true;
    private int     targetFps    = 60;
    private int     checkCooldown = 0;

    // Simpan setting asli player
    private boolean originalParticles  = false;
    private boolean boosted            = false;

    public void onTick(MinecraftClient client) {
        if (!enabled || client.player == null) return;

        checkCooldown--;
        if (checkCooldown > 0) return;
        checkCooldown = 40; // cek setiap 2 detik

        int fps = client.getCurrentFps();

        if (fps < targetFps - 10 && !boosted) {
            applyBoost(client);
        } else if (fps >= targetFps && boosted) {
            removeBoost(client);
        }
    }

    private void applyBoost(MinecraftClient client) {
        boosted = true;
        // Kurangi partikel
        client.options.getParticles().setValue(
            net.minecraft.client.option.ParticlesMode.DECREASED
        );
        // Matikan clouds
        client.options.getCloudRenderModeOption().setValue(
            net.minecraft.client.option.CloudRenderMode.OFF
        );
        // Entity distance dikurangi
        if (client.options.getEntityDistanceScaling().getValue() > 0.5) {
            client.options.getEntityDistanceScaling().setValue(0.5);
        }
        client.options.write();
    }

    private void removeBoost(MinecraftClient client) {
        boosted = false;
        // Kembalikan partikel
        client.options.getParticles().setValue(
            net.minecraft.client.option.ParticlesMode.ALL
        );
        // Kembalikan clouds
        client.options.getCloudRenderModeOption().setValue(
            net.minecraft.client.option.CloudRenderMode.FAST
        );
        // Kembalikan entity distance
        client.options.getEntityDistanceScaling().setValue(1.0);
        client.options.write();
    }

    public boolean isEnabled()       { return enabled; }
    public void toggle()             { enabled = !enabled; }
    public boolean isBoosted()       { return boosted; }
    public int getTargetFps()        { return targetFps; }
    public void setTargetFps(int v)  { targetFps = v; }
}
