package com.smoothpvp.features;

import net.minecraft.client.MinecraftClient;

public class AutoSprintFeature {

    private boolean enabled = true;

    public void onTick(MinecraftClient client) {
        if (!enabled) return;
        if (client.player == null) return;

        // Auto sprint saat bergerak maju
        if (client.options.forwardKey.isPressed()
                && !client.player.isSprinting()
                && !client.player.isSneaking()
                && client.player.getHungerManager().getFoodLevel() > 6) {
            client.player.setSprinting(true);
        }
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { enabled = !enabled; }
    public void setEnabled(boolean v) { enabled = v; }
}
