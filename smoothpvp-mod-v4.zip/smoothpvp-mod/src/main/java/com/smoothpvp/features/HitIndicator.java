package com.smoothpvp.features;

public class HitIndicator {

    private int flashTicks = 0;
    private static final int FLASH_DURATION = 5;

    public void onHit() {
        flashTicks = FLASH_DURATION;
    }

    public void tick() {
        if (flashTicks > 0) flashTicks--;
    }

    public boolean isFlashing() { return flashTicks > 0; }

    public float getAlpha() {
        return (float) flashTicks / FLASH_DURATION;
    }
}
