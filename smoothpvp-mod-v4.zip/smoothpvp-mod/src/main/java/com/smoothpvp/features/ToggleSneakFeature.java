package com.smoothpvp.features;

import net.minecraft.client.MinecraftClient;

public class ToggleSneakFeature {

    private boolean enabled  = false;
    private boolean sneaking = false;
    private boolean wasPressed = false;

    public void onTick(MinecraftClient client) {
        if (!enabled) return;
        if (client.player == null) return;

        boolean pressed = client.options.sneakKey.isPressed();

        // Toggle sneak saat tombol ditekan (bukan ditahan)
        if (pressed && !wasPressed) {
            sneaking = !sneaking;
        }
        wasPressed = pressed;

        client.options.sneakKey.setPressed(sneaking);
    }

    public boolean isEnabled() { return enabled; }
    public void toggle()       { enabled = !enabled; sneaking = false; }
}
