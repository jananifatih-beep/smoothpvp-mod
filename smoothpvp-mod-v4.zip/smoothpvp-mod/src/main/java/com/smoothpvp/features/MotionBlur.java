package com.smoothpvp.features;

import net.minecraft.client.MinecraftClient;

/**
 * Motion Blur - menyimpan alpha blend antar frame
 * Dirender di SmoothHUD via overlay semi-transparan
 */
public class MotionBlur {

    private boolean enabled = true;
    private float   strength = 0.6f; // 0.0 = off, 1.0 = max blur

    // Simpan posisi kamera sebelumnya untuk efek blur
    private float prevYaw   = 0f;
    private float prevPitch = 0f;
    private float deltaYaw  = 0f;
    private float deltaPitch = 0f;

    public void onTick(MinecraftClient client) {
        if (!enabled || client.player == null) return;

        float yaw   = client.player.getYaw();
        float pitch = client.player.getPitch();

        deltaYaw   = Math.abs(yaw - prevYaw);
        deltaPitch = Math.abs(pitch - prevPitch);

        prevYaw   = yaw;
        prevPitch = pitch;
    }

    /** Alpha overlay blur: makin banyak gerak kamera = makin blur */
    public int getBlurAlpha() {
        if (!enabled) return 0;
        float motion = Math.min((deltaYaw + deltaPitch) * 0.5f, 1.0f);
        return (int)(motion * strength * 120);
    }

    public boolean isEnabled()           { return enabled; }
    public void toggle()                 { enabled = !enabled; }
    public void setStrength(float v)     { strength = Math.max(0, Math.min(1, v)); }
    public float getStrength()           { return strength; }
}
