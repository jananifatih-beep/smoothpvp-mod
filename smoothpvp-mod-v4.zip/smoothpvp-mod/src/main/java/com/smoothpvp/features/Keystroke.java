package com.smoothpvp.features;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

/**
 * Keystroke - tampilkan tombol WASD, Space, Shift, LMB, RMB di layar
 */
public class Keystroke {

    private boolean enabled = true;

    public boolean isEnabled() { return enabled; }
    public void toggle()       { enabled = !enabled; }

    public boolean isForward(MinecraftClient client) {
        return client.options.forwardKey.isPressed();
    }
    public boolean isBack(MinecraftClient client) {
        return client.options.backKey.isPressed();
    }
    public boolean isLeft(MinecraftClient client) {
        return client.options.leftKey.isPressed();
    }
    public boolean isRight(MinecraftClient client) {
        return client.options.rightKey.isPressed();
    }
    public boolean isJump(MinecraftClient client) {
        return client.options.jumpKey.isPressed();
    }
    public boolean isSneak(MinecraftClient client) {
        return client.options.sneakKey.isPressed();
    }
    public boolean isAttack(MinecraftClient client) {
        return client.options.attackKey.isPressed();
    }
    public boolean isUse(MinecraftClient client) {
        return client.options.useKey.isPressed();
    }
}
