package com.smoothpvp.mixin;

import com.smoothpvp.SmoothPvP;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.entity.damage.DamageSource;

@Mixin(ClientPlayerEntity.class)
public class PlayerHurtMixin {

    @Inject(method = "damage", at = @At("HEAD"))
    private void onDamage(DamageSource source, float amount, CallbackInfo ci) {
        if (SmoothPvP.hud != null) {
            SmoothPvP.hud.getHitIndicator().onHit();
        }
    }
}
