package com.smoothpvp;

import com.smoothpvp.features.*;
import com.smoothpvp.hud.SmoothHUD;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SmoothPvP implements ClientModInitializer {

    public static final String MOD_ID = "smoothpvp";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static AutoSprintFeature  autoSprint;
    public static ToggleSneakFeature toggleSneak;
    public static MotionBlur         motionBlur;
    public static Keystroke          keystroke;
    public static FpsBoost           fpsBoost;
    public static NoParticle         noParticle;
    public static SmoothHUD          hud;
    public static boolean            hudVisible = true;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[SmoothPvP] Initializing v2.2...");

        autoSprint  = new AutoSprintFeature();
        toggleSneak = new ToggleSneakFeature();
        motionBlur  = new MotionBlur();
        keystroke   = new Keystroke();
        fpsBoost    = new FpsBoost();
        noParticle  = new NoParticle();
        hud         = new SmoothHUD();

        // Daftarkan semua keybind
        KeyBindings.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // Cek tombol ditekan
            if (KeyBindings.toggleAutoSprint.wasPressed())  autoSprint.toggle();
            if (KeyBindings.toggleSneak.wasPressed())       toggleSneak.toggle();
            if (KeyBindings.toggleMotionBlur.wasPressed())  motionBlur.toggle();
            if (KeyBindings.toggleKeystroke.wasPressed())   keystroke.toggle();
            if (KeyBindings.toggleNoParticle.wasPressed())  noParticle.toggle();
            if (KeyBindings.toggleFpsBoost.wasPressed())    fpsBoost.toggle();
            if (KeyBindings.toggleHud.wasPressed())         hudVisible = !hudVisible;

            // Tick fitur
            autoSprint.onTick(client);
            toggleSneak.onTick(client);
            motionBlur.onTick(client);
            fpsBoost.onTick(client);
            noParticle.onTick(client);
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || !hudVisible) return;
            hud.render(drawContext, client, tickDelta);
        });

        LOGGER.info("[SmoothPvP] Ready! All features loaded.");
    }
}
