package com.smoothpvp.hud;

import com.smoothpvp.SmoothPvP;
import com.smoothpvp.features.HitIndicator;
import com.smoothpvp.features.Keystroke;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

public class SmoothHUD {

    private final HitIndicator hitIndicator = new HitIndicator();

    public HitIndicator getHitIndicator() { return hitIndicator; }

    public void render(DrawContext ctx, MinecraftClient client, float tickDelta) {
        PlayerEntity player = client.player;
        if (player == null) return;

        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();

        hitIndicator.tick();

        // 1. Motion Blur overlay
        renderMotionBlur(ctx, sw, sh);

        // 2. Hit indicator
        if (hitIndicator.isFlashing()) {
            int alpha = (int)(hitIndicator.getAlpha() * 80);
            ctx.fill(0, 0, sw, sh, (alpha << 24) | 0xFF0000);
        }

        // 3. Health bar
        renderHealthBar(ctx, client, player, sw, sh);

        // 4. Armor status
        renderArmorStatus(ctx, client, player, sw, sh);

        // 5. Sprint indicator
        renderSprintIndicator(ctx, client, player, sw, sh);

        // 6. Custom crosshair
        renderCrosshair(ctx, sw, sh);

        // 7. FPS counter
        renderFPS(ctx, client);

        // 8. Ping
        renderPing(ctx, client);

        // 9. Item info
        renderItemInfo(ctx, client, player, sw, sh);

        // 10. Status toggles
        renderStatusToggles(ctx, client, sw, sh);

        // 11. Keystroke display
        renderKeystrokes(ctx, client, sw, sh);

        // 12. FPS Boost status
        renderFpsBoostStatus(ctx, client, sw);
    }

    // --- Motion Blur overlay ---
    private void renderMotionBlur(DrawContext ctx, int sw, int sh) {
        if (!SmoothPvP.motionBlur.isEnabled()) return;
        int alpha = SmoothPvP.motionBlur.getBlurAlpha();
        if (alpha <= 0) return;
        // Overlay hitam semi-transparan sesuai gerakan kamera
        ctx.fill(0, 0, sw, sh, (alpha << 24) | 0x000000);
    }

    // --- Health Bar ---
    private void renderHealthBar(DrawContext ctx, MinecraftClient mc, PlayerEntity player, int sw, int sh) {
        float health    = player.getHealth();
        float maxHealth = player.getMaxHealth();
        float ratio     = health / maxHealth;

        int barW = 100, barH = 6;
        int x = sw / 2 - barW / 2;
        int y = sh - 49;

        ctx.fill(x - 1, y - 1, x + barW + 1, y + barH + 1, 0xAA000000);

        int color = ratio > 0.6f ? 0xFF44FF44 : ratio > 0.3f ? 0xFFFFAA00 : 0xFFFF3333;
        ctx.fill(x, y, x + (int)(barW * ratio), y + barH, color);

        String hpText = (int)health + " / " + (int)maxHealth;
        ctx.drawTextWithShadow(mc.textRenderer, hpText,
                x + barW / 2 - mc.textRenderer.getWidth(hpText) / 2, y - 10, 0xFFFFFFFF);
    }

    // --- Armor ---
    private void renderArmorStatus(DrawContext ctx, MinecraftClient mc, PlayerEntity player, int sw, int sh) {
        int armor = player.getArmor();
        int color = armor > 15 ? 0xFF44FF44 : armor > 8 ? 0xFFFFAA00 : 0xFFFF4444;
        ctx.drawTextWithShadow(mc.textRenderer, "Armor: " + armor, sw / 2 - 50, sh - 60, color);
    }

    // --- Sprint ---
    private void renderSprintIndicator(DrawContext ctx, MinecraftClient mc, PlayerEntity player, int sw, int sh) {
        String text = player.isSprinting() ? "§aSPRINT" : "§7WALK";
        ctx.drawTextWithShadow(mc.textRenderer, text, sw - 60, sh - 30, 0xFFFFFFFF);
    }

    // --- Custom Crosshair ---
    private void renderCrosshair(DrawContext ctx, int sw, int sh) {
        int cx = sw / 2, cy = sh / 2;
        int size = 5, gap = 2;
        int color = 0xFFFFFFFF;
        ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, color);
        ctx.fill(cx - 1, cy - size - gap, cx + 1, cy - gap, color);
        ctx.fill(cx - 1, cy + gap, cx + 1, cy + size + gap, color);
        ctx.fill(cx - size - gap, cy - 1, cx - gap, cy + 1, color);
        ctx.fill(cx + gap, cy - 1, cx + size + gap, cy + 1, color);
    }

    // --- FPS ---
    private void renderFPS(DrawContext ctx, MinecraftClient mc) {
        int fps   = mc.getCurrentFps();
        int color = fps >= 60 ? 0xFF44FF44 : fps >= 30 ? 0xFFFFAA00 : 0xFFFF4444;
        ctx.drawTextWithShadow(mc.textRenderer, "FPS: " + fps, 4, 4, color);
    }

    // --- Ping ---
    private void renderPing(DrawContext ctx, MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return;
        var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        if (entry == null) return;
        int ping  = entry.getLatency();
        int color = ping < 80 ? 0xFF44FF44 : ping < 150 ? 0xFFFFAA00 : 0xFFFF4444;
        ctx.drawTextWithShadow(mc.textRenderer, "Ping: " + ping + "ms", 4, 14, color);
    }

    // --- Item Info ---
    private void renderItemInfo(DrawContext ctx, MinecraftClient mc, PlayerEntity player, int sw, int sh) {
        ItemStack held = player.getMainHandStack();
        if (held.isEmpty()) return;
        String name = held.getName().getString();
        int x = sw / 2 - mc.textRenderer.getWidth(name) / 2;
        ctx.drawTextWithShadow(mc.textRenderer, name, x, sh - 70, 0xFFFFFFAA);
        if (held.isDamageable()) {
            int dur = held.getMaxDamage() - held.getDamage();
            int max = held.getMaxDamage();
            float ratio = (float) dur / max;
            int col = ratio > 0.5f ? 0xFF44FF44 : ratio > 0.25f ? 0xFFFFAA00 : 0xFFFF4444;
            String durText = "Durability: " + dur + "/" + max;
            ctx.drawTextWithShadow(mc.textRenderer, durText,
                    sw / 2 - mc.textRenderer.getWidth(durText) / 2, sh - 80, col);
        }
    }

    // --- Status Toggles ---
    private void renderStatusToggles(DrawContext ctx, MinecraftClient mc, int sw, int sh) {
        // Background panel
        ctx.fill(0, sh - 75, 130, sh - 10, 0x88000000);

        ctx.drawTextWithShadow(mc.textRenderer,
                "§eAutoSprint §r"  + (SmoothPvP.autoSprint.isEnabled()  ? "§aON" : "§cOFF") + " §7[R]",  4, sh - 70, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer,
                "§eToggleSneak §r" + (SmoothPvP.toggleSneak.isEnabled() ? "§aON" : "§cOFF") + " §7[Z]",  4, sh - 60, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer,
                "§eMotionBlur §r"  + (SmoothPvP.motionBlur.isEnabled()  ? "§aON" : "§cOFF") + " §7[B]",  4, sh - 50, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer,
                "§eNoParticle §r"  + (SmoothPvP.noParticle.isEnabled()  ? "§aON" : "§cOFF") + " §7[N]",  4, sh - 40, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer,
                "§eKeystroke §r"   + (SmoothPvP.keystroke.isEnabled()   ? "§aON" : "§cOFF") + " §7[K]",  4, sh - 30, 0xFFFFFFFF);
        ctx.drawTextWithShadow(mc.textRenderer,
                "§eFpsBoost §r"    + (SmoothPvP.fpsBoost.isEnabled()    ? "§aON" : "§cOFF") + " §7[F]",  4, sh - 20, 0xFFFFFFFF);
    }

    // --- Keystroke Display ---
    private void renderKeystrokes(DrawContext ctx, MinecraftClient mc, int sw, int sh) {
        if (!SmoothPvP.keystroke.isEnabled()) return;

        Keystroke ks = SmoothPvP.keystroke;
        int keyW = 20, keyH = 14, gap = 2;
        int baseX = sw - 70;
        int baseY = sh - 100;

        drawKey(ctx, mc, "W",   baseX + keyW + gap, baseY,                    ks.isForward(mc));
        drawKey(ctx, mc, "A",   baseX,               baseY + keyH + gap,       ks.isLeft(mc));
        drawKey(ctx, mc, "S",   baseX + keyW + gap,  baseY + keyH + gap,       ks.isBack(mc));
        drawKey(ctx, mc, "D",   baseX + (keyW+gap)*2, baseY + keyH + gap,      ks.isRight(mc));
        drawKey(ctx, mc, "SPC", baseX,               baseY + (keyH+gap)*2,     ks.isJump(mc));
        drawKey(ctx, mc, "SHF", baseX + (keyW+gap)*2, baseY + (keyH+gap)*2,   ks.isSneak(mc));
        drawKey(ctx, mc, "LMB", baseX,               baseY + (keyH+gap)*3,     ks.isAttack(mc));
        drawKey(ctx, mc, "RMB", baseX + (keyW+gap)*2, baseY + (keyH+gap)*3,   ks.isUse(mc));
    }

    private void drawKey(DrawContext ctx, MinecraftClient mc, String label, int x, int y, boolean pressed) {
        int keyW = 20, keyH = 14;
        int bg    = pressed ? 0xCCFFFFFF : 0xAA222222;
        int text  = pressed ? 0xFF000000 : 0xFFAAAAAA;

        ctx.fill(x, y, x + keyW, y + keyH, bg);
        int tx = x + keyW / 2 - mc.textRenderer.getWidth(label) / 2;
        int ty = y + keyH / 2 - 4;
        ctx.drawTextWithShadow(mc.textRenderer, label, tx, ty, text);
    }

    // --- FPS Boost status ---
    private void renderFpsBoostStatus(DrawContext ctx, MinecraftClient mc, int sw) {
        boolean boosted = SmoothPvP.fpsBoost.isBoosted();
        String text = "FPSBoost: " + (SmoothPvP.fpsBoost.isEnabled()
                ? (boosted ? "§eACTIVE" : "§aSTANDBY")
                : "§cOFF");
        ctx.drawTextWithShadow(mc.textRenderer, text, 4, 24, 0xFFFFFFFF);
    }
}
