package com.smoothpvp;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

    public static KeyBinding toggleAutoSprint;
    public static KeyBinding toggleSneak;
    public static KeyBinding toggleMotionBlur;
    public static KeyBinding toggleKeystroke;
    public static KeyBinding toggleNoParticle;
    public static KeyBinding toggleFpsBoost;
    public static KeyBinding toggleHud;

    public static void register() {
        // Kategori muncul di Options > Controls > SmoothPvP
        String category = "SmoothPvP";

        toggleAutoSprint = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Toggle AutoSprint", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R, category));

        toggleSneak = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Toggle Sneak", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_Z, category));

        toggleMotionBlur = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Toggle Motion Blur", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_B, category));

        toggleKeystroke = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Toggle Keystroke", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K, category));

        toggleNoParticle = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Toggle No Particle", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_N, category));

        toggleFpsBoost = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Toggle FPS Boost", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F, category));

        toggleHud = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Toggle HUD", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H, category));
    }
}
