==================================================
  SmoothPvP Mod v1.0 - Minecraft Java 1.21
  Legal PvP Utility Mod untuk Fabric
==================================================

FITUR:
  ✅ AutoSprint     - Sprint otomatis saat jalan maju
  ✅ Toggle Sneak   - Sneak tanpa tahan tombol
  ✅ Hit Indicator  - Layar flash merah saat kena pukul
  ✅ Custom HUD     - Health bar, armor, sprint status
  ✅ Custom Crosshair - Crosshair bersih & presisi
  ✅ FPS Counter    - Tampil di pojok kiri atas
  ✅ Ping Display   - Ping real-time ke server
  ✅ Item Info      - Nama & durabilitas item di tangan
  ✅ Status Toggle  - Tampil ON/OFF AutoSprint & Sneak

==================================================
  CARA COMPILE (jadi file .jar)
==================================================

SYARAT:
  - Java JDK 21 (https://adoptium.net)
  - Internet (untuk download dependensi)

LANGKAH:
  1. Install Java JDK 21
  2. Ekstrak folder smoothpvp-mod ini
  3. Buka Terminal / Command Prompt di folder tersebut
  4. Jalankan perintah:

     Windows  : gradlew.bat build
     Mac/Linux: ./gradlew build

  5. Tunggu proses download & compile (5-10 menit pertama kali)
  6. File .jar ada di: build/libs/smoothpvp-1.0.0.jar

CARA INSTALL MOD:
  1. Install Fabric Loader untuk Minecraft 1.21
     (https://fabricmc.net/use)
  2. Install Fabric API
     (https://modrinth.com/mod/fabric-api)
  3. Copy file smoothpvp-1.0.0.jar ke folder:
     Windows : %appdata%\.minecraft\mods\
     Mac     : ~/Library/Application Support/minecraft/mods/
     Linux   : ~/.minecraft/mods/
  4. Jalankan Minecraft dengan profile Fabric
  5. Selesai!

==================================================
  CATATAN
==================================================
  - Mod ini 100% legal dan aman di server survival/PvP biasa
  - Tidak ada fitur cheat (killaura, reach, ESP, dll)
  - Dibuat dengan Claude AI
==================================================
